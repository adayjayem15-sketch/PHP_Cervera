    @if (session('success'))
        <div class="alert theme-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
        </div>
    @endif

    @if (session('error'))
        <div class="alert theme-danger alert-dismissible fade show" role="alert">
            {{ session('error') }}
        </div>
    @endif